package edu.seminolestate.overdriveluck.fragments

import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import edu.seminolestate.overdriveluck.MainActivity
import edu.seminolestate.overdriveluck.R
import kotlin.system.exitProcess

class QuitFragment : AppCompatActivity(){

    /*

    class QuitFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        lateinit var closeApplicationBtn: Button

        val view = inflater.inflate(R.layout.fragment_quit, container, false)
        closeApplicationBtn = requireView().findViewById<Button>(R.id.idBtnCloseApplication).apply {
            this.movementMethod = LinkMovementMethod.getInstance()
        }
            val activity = MainActivity()
            closeApplicationBtn.setOnClickListener {
                activity.finish()
                exitProcess(0)
            }

        return view
    }
    **/

    // on below line we are creating a variable.
    lateinit var closeApplicationBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_quit)

        // on below line we are creating and
        // initializing variable for activity
        val activity: MainActivity = MainActivity()

        // on below line we are initializing our variables.
        closeApplicationBtn = findViewById(R.id.idBtnCloseApplication)

        // on below line we are adding click listener for our button
        closeApplicationBtn.setOnClickListener {
            // on below line we are finishing activity.
            activity.finish()

            // on below line we are exiting our activity
            System.exit(0)
        }
    }
}